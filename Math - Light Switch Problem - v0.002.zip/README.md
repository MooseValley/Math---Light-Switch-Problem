# Math - Light Switch Problem

See:
* The Light Switch Problem - Numberphile, https://www.youtube.com/watch?v=-UBDRX6bk-A

Moose
